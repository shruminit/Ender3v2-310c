build
Creality ender 3 v2 (has the earlier 4.2.2 board)
Microswiss all metal hot end
Capricorn ptfe tubing
104gt-2 rated thermistor (link below)
Ruby tipped nozzle
CR touch
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Disclaimer: This is how I did this. I am not Liable for any damages from anyone modifying their printer.

I did these upgrades so I could print in Bambu Labs PA6-CF which has a recommended print temperature range of 260-290c.
Thermistor upgrade is recommended to prevent Teflon off-gassing from stock thermistor. PID tune is recommended if hot end cannot keep a consistent temperature (greater or equal to 1 degree change every 5 minutes).
Operating range for the printer is best suited up to around 290c but can reach 310c.



Parts required:
Microswiss all metal hot end for ender 3v2
Thermistor- Thermistor-104NT-4-R025H42G-Temperature-Extruder on Amazon
CRtouch/ BLtouch auto bed level
Capricorn ptfe bowden tube
Ruby tipped nozzle or any other abrasive resistant nozzle(A hardened steel one is supplied with Microswiss)
Enclosure and filament dryer highly recommended.


Procedure:
Step 1: Find which .bin file is for your printer. Board generation can be found on ender board (.bin files for both 4.2.2 and 4.2.7 boards can be found in files provided). 
Step 2: Upload .bin file to the printer. Do this by  inserting the micro sd card  into the front slot with the printer turned off. turn the printer on and let it boot up. Remove the .bin file from the card when finished.
Step 3: Upload the DWIN set and private files from the LCD files folder onto the sd card and install into the sd card slot on the screen board. Boot up printer. The screen will turn blue. When it turns red, turn off the printer and remove the sd card. Boot up the printer to verify proper install (icons should all be present).
Step 3: Confirm that step 2 worked by scrolling through the nozzle temp range to 300c.
Step 4: Turn off printer and install screw in thermistor. Thermistor will fit in the stock fan shroud but it will be tight.
Step 5: Bring hot end up to 290c. watch temp for 5 minutes to see if there is any fluctuation. Now do the same for 300c. PID tune can be performed now (link below under PID tune).
Step 6: Fix slicer settings for printing with new hot-end. I have mine down below. Change z axis offset to appropriate printing level.


PID tune:
Baud rate 115200
PID AUTOTUNE- https://www.youtube.com/watch?v=cl-B9SrlzMY


Slicer settings:
Cura
layer height: .16mm
wall thickness: .8mm
wall line count: 2mm
horizontal expansion: 0mm 
top/bottom thickness: .78mm
top layers: 5
bottom layers: 5
infill density: 99%
infill pattern: gyroid
print temperature: 290 degrees
build plate: 50 degrees
print speed: 50mm/s
enable retraction
retraction distance: 1.5mm
retraction speed: 50mm/s
retraction retract speed: 50mm/s
retraction prime speed: 30mm/s
combing mode: not in skin
generate support: on
support structure: normal
support placement: everywhere
support overhang angle: 51 degrees
support horizontal expansion: .8mm
build plate adhesion type: brim

(your settings may be different but this has been left for a rough starting guide on tuning your printer)



Config files have been left for the more technologically literate.
(hot end thermistor change is set up with #DEFINE_TEMP_SENSOR_ 0 5 as it's calibration)



References for doing the config edit yourself:
This build utilizes Marlin version 2.1.2.1
FIRMWARE UPLOADING-https://www.youtube.com/watch?v=y87P7K5DTMU&t=191s
BASICS AND HOTEND TEMP- https://notenoughtech.com/3dupgrades/compiling-marlin-2-0-for-ender3-v2/
CRTOUCH- https://www.youtube.com/watch?v=iaQSXZsybl0 
(USE CR TOUCH LINK FOR ANY CR TOUCH CONFIGS)